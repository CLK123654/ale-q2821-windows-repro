from __future__ import annotations

from datetime import datetime

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator, ShortCircuitOperator
from airflow.utils.trigger_rule import TriggerRule


CHANNEL_TASK = {
    "api": "deploy_api",
    "web": "deploy_web",
    "mobile": "deploy_mobile",
}


def selected_channel_tasks(**context):
    dag_run = context.get("dag_run")
    channels = (dag_run.conf or {}).get("channels", []) if dag_run else []
    if isinstance(channels, str):
        channels = [] if channels == "none" else channels.split(";")
    targets = [CHANNEL_TASK[channel] for channel in channels if channel in CHANNEL_TASK]
    return targets or "no_channel"


def risk_allows_promotion(**context):
    dag_run = context.get("dag_run")
    conf = (dag_run.conf or {}) if dag_run else {}
    channels = conf.get("channels", [])
    if isinstance(channels, str):
        channels = [] if channels == "none" else channels.split(";")
    return bool(channels) and conf.get("risk_decision", "BLOCK") == "ALLOW"


with DAG(
    dag_id="internet_multichannel_release",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
    render_template_as_native_obj=True,
    tags=["internet", "release", "state-convergence"],
) as dag:
    load_manifest = EmptyOperator(task_id="load_manifest")
    choose_channels = BranchPythonOperator(
        task_id="choose_channels",
        python_callable=selected_channel_tasks,
    )
    deploy_api = EmptyOperator(task_id="deploy_api")
    deploy_web = EmptyOperator(task_id="deploy_web")
    deploy_mobile = EmptyOperator(task_id="deploy_mobile")
    no_channel = EmptyOperator(task_id="no_channel")
    selected_join = EmptyOperator(
        task_id="selected_join",
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
    )
    risk_gate = ShortCircuitOperator(
        task_id="risk_gate",
        python_callable=risk_allows_promotion,
        ignore_downstream_trigger_rules=False,
    )
    promote = EmptyOperator(task_id="promote")
    finalize = EmptyOperator(
        task_id="finalize",
        trigger_rule=TriggerRule.ALL_DONE,
    )

    load_manifest >> choose_channels
    choose_channels >> [deploy_api, deploy_web, deploy_mobile, no_channel]
    [deploy_api, deploy_web, deploy_mobile, no_channel] >> selected_join
    selected_join >> risk_gate >> promote >> finalize
