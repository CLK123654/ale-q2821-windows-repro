from __future__ import annotations

import csv
import json
import os
from pathlib import Path

from airflow.models import DagBag


INPUT_FILES = ["README.md", "broken_dag.py", "release_scenarios.csv", "state_contract.json"]
DAG_FILES = ["internet_multichannel_release.py"]
RESULT_FILES = [
    "branch_decisions.csv",
    "scenario_states.csv",
    "state_summary.json",
    "task_graph.csv",
    "trigger_truth_table.csv",
    "validation.json",
]


def files(root: Path) -> list[str]:
    return sorted(
        str(path.relative_to(root)).replace(os.sep, "/")
        for path in root.rglob("*")
        if path.is_file()
    )


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


input_root = Path(os.environ["ALE_INPUT_ROOT"])
dag_root = Path(os.environ["ALE_DAG_ROOT"])
result_root = Path(os.environ["ALE_OUTPUT_ROOT"])
assert files(input_root) == INPUT_FILES
assert files(dag_root) == DAG_FILES
assert files(result_root) == RESULT_FILES
contract = json.loads((input_root / "state_contract.json").read_text(encoding="utf-8"))
assert contract["contract_id"] == "internet-release-skip-v2"

bag = DagBag(dag_folder=str(dag_root), include_examples=False, safe_mode=False)
assert not bag.import_errors
dag = bag.dags[contract["dag_id"]]
assert dag.task_ids == contract["task_order"]
assert dag.get_task("choose_channels").__class__.__name__ == "BranchPythonOperator"
assert dag.get_task("choose_channels").downstream_task_ids == set(contract["branch_targets"])
assert dag.get_task("selected_join").upstream_task_ids == set(contract["branch_targets"])
assert str(dag.get_task("selected_join").trigger_rule) == "none_failed_min_one_success"
assert dag.get_task("risk_gate").__class__.__name__ == "ShortCircuitOperator"
assert dag.get_task("risk_gate").ignore_downstream_trigger_rules is False
assert dag.get_task("finalize").upstream_task_ids == {"promote"}
assert str(dag.get_task("finalize").trigger_rule) == "all_done"

expected_graph = []
for task_id in contract["task_order"]:
    task = dag.get_task(task_id)
    expected_graph.append(
        {
            "task_id": task_id,
            "class_name": task.__class__.__name__,
            "trigger_rule": str(task.trigger_rule),
            "upstream": ";".join(sorted(task.upstream_task_ids)),
            "downstream": ";".join(sorted(task.downstream_task_ids)),
            "ignore_downstream_trigger_rules": str(
                getattr(task, "ignore_downstream_trigger_rules", "")
            ).lower(),
        }
    )
assert rows(result_root / "task_graph.csv") == expected_graph

expected_states = []
expected_decisions = []
scenario_rows = rows(input_root / "release_scenarios.csv")
assert [row["scenario_id"] for row in scenario_rows] == contract["scenario_order"]
for scenario in scenario_rows:
    channels = [] if scenario["channels"] == "none" else scenario["channels"].split(";")
    task_states = {"load_manifest": "SUCCESS", "choose_channels": "SUCCESS"}
    targets = []
    for channel, task_id in contract["channel_task_map"].items():
        selected = channel in channels
        task_states[task_id] = scenario[f"{channel}_state"] if selected else "SKIPPED"
        if selected:
            targets.append(task_id)
    if not targets:
        targets = ["no_channel"]
    task_states["no_channel"] = "SUCCESS" if not channels else "SKIPPED"
    upstream = [task_states[task_id] for task_id in contract["branch_targets"]]
    if "FAILED" in upstream or "UPSTREAM_FAILED" in upstream:
        join_state = "UPSTREAM_FAILED"
    elif "SUCCESS" in upstream:
        join_state = "SUCCESS"
    else:
        join_state = "SKIPPED"
    task_states["selected_join"] = join_state
    task_states["risk_gate"] = "SUCCESS" if join_state == "SUCCESS" else join_state
    allows = bool(channels) and scenario["risk_decision"] == "ALLOW"
    task_states["promote"] = (
        "SUCCESS"
        if join_state == "SUCCESS" and allows
        else "SKIPPED"
        if join_state in {"SUCCESS", "SKIPPED"}
        else "UPSTREAM_FAILED"
    )
    task_states["finalize"] = "SUCCESS"
    expected_decisions.append(
        {
            "scenario_id": scenario["scenario_id"],
            "branch_targets": ";".join(targets),
            "short_circuit_allows": str(allows).lower(),
            "join_state": join_state,
            "promote_state": task_states["promote"],
            "finalize_state": "SUCCESS",
        }
    )
    expected_states.extend(
        {
            "scenario_id": scenario["scenario_id"],
            "task_id": task_id,
            "state": task_states[task_id],
        }
        for task_id in contract["task_order"]
    )
assert rows(result_root / "branch_decisions.csv") == expected_decisions
assert rows(result_root / "scenario_states.csv") == expected_states

expected_truth = []
for case in contract["truth_cases"]:
    if case["failed"] > 0:
        decision, terminal = "BLOCK", "UPSTREAM_FAILED"
    elif case["success"] > 0:
        decision, terminal = "RUN", "SUCCESS"
    else:
        decision, terminal = "BLOCK", "SKIPPED"
    expected_truth.append(
        {
            "case_id": case["case_id"],
            "success": str(case["success"]),
            "failed": str(case["failed"]),
            "skipped": str(case["skipped"]),
            "decision": decision,
            "terminal_state": terminal,
        }
    )
assert rows(result_root / "trigger_truth_table.csv") == expected_truth

summary = json.loads((result_root / "state_summary.json").read_text(encoding="utf-8"))
validation = json.loads((result_root / "validation.json").read_text(encoding="utf-8"))
assert summary["contract_id"] == "internet-release-skip-v2"
assert summary["tasks"] == 10 and summary["scenarios"] == 10
assert summary["state_rows"] == 100 and summary["branch_decision_rows"] == 10
assert summary["truth_cases"] == 8
assert summary["state_counts"] == {
    "SUCCESS": 62,
    "SKIPPED": 30,
    "FAILED": 2,
    "UPSTREAM_FAILED": 6,
}
assert validation["result"] == "PASS"
assert validation["engine"]["airflow_version"] == "2.10.5"
assert validation["engine"]["scheduler_started"] is False
assert validation["engine"]["metadata_database_accessed"] is False
assert validation["engine"]["network_access"] is False
assert len(validation["invariants"]) == 20 and all(validation["invariants"].values())

dag_source = (dag_root / DAG_FILES[0]).read_text(encoding="utf-8").lower()
for forbidden in ("requests.", "urllib.", "simplehttpoperator", "httpoperator"):
    assert forbidden not in dag_source

print("5176 independent Airflow convergence test PASS")
