# Apache Airflow release-convergence reference

`dags/internet_multichannel_release.py` is imported by Apache Airflow2.10.5`DagBag`. The audit reads the real operator classes, task edges, trigger rules and`ShortCircuitOperator.ignore_downstream_trigger_rules`; it does not replace those properties with values from the contract.

`tools/audit_release_dag.py` validates the exact four-file input and one-file DAG boundaries, recomputes all ten scenario state vectors and eight join truth cases, writes six results to a sibling staging directory, and invokes`tests/test_results.py` before publishing. The test has a separate state evaluator and re-imports the DAG, so it does not import the audit implementation or accept a`PASS` string as proof.

Run in an Airflow2.10.5environment:

```bash
AIRFLOW_PYTHON=/path/to/airflow-python \
ALE_INPUT_ROOT=/path/to/input_data \
ALE_DAG_ROOT=/path/to/reference/dags \
ALE_OUTPUT_ROOT=/tmp/release-state-results \
./run.sh
```

The output directory must be absent or empty. A successful run publishes exactly six files; a failed check removes staging and leaves no complete delivery. The isolated`AIRFLOW_HOME` is used only for imports. The workflow does not start scheduler components, initialize a metadata database, contact release endpoints or use the network.
