#!/usr/bin/env bash
set -euo pipefail

reference_root="$(cd "$(dirname "$0")" && pwd)"
airflow_python="${AIRFLOW_PYTHON:?AIRFLOW_PYTHON must point to Airflow 2.10.5 Python}"
input_root="${ALE_INPUT_ROOT:?ALE_INPUT_ROOT is required}"
dag_root="${ALE_DAG_ROOT:-$reference_root/dags}"
output_root="${ALE_OUTPUT_ROOT:?ALE_OUTPUT_ROOT is required}"
airflow_home="$(mktemp -d)"
trap 'rm -rf "$airflow_home"' EXIT

export AIRFLOW_HOME="$airflow_home"
export AIRFLOW__CORE__LOAD_EXAMPLES=False
export AIRFLOW__CORE__UNIT_TEST_MODE=True
export AIRFLOW__LOGGING__LOGGING_LEVEL=ERROR

"$airflow_python" "$reference_root/tools/audit_release_dag.py" \
  "$reference_root" "$input_root" "$dag_root" "$output_root"
