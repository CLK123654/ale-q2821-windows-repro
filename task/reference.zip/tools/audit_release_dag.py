from __future__ import annotations

import csv
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import airflow
from airflow.models import DagBag


INPUT_FILES = [
    "README.md",
    "broken_dag.py",
    "release_scenarios.csv",
    "state_contract.json",
]
DAG_FILES = ["internet_multichannel_release.py"]
RESULT_FILES = [
    "branch_decisions.csv",
    "scenario_states.csv",
    "state_summary.json",
    "task_graph.csv",
    "trigger_truth_table.csv",
    "validation.json",
]
SCENARIO_HEADERS = [
    "scenario_id",
    "channels",
    "api_state",
    "web_state",
    "mobile_state",
    "risk_decision",
]


def relative_files(directory: Path) -> list[str]:
    return sorted(
        str(path.relative_to(directory)).replace(os.sep, "/")
        for path in directory.rglob("*")
        if path.is_file()
    )


def load_csv(path: Path, expected_headers: list[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != expected_headers:
            raise ValueError(f"{path.name}: header mismatch")
        rows = list(reader)
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError(f"{path.name}: malformed row")
    return rows


def write_csv(path: Path, headers: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def graph_rows(dag, task_order: list[str]) -> list[dict[str, str]]:
    rows = []
    for task_id in task_order:
        task = dag.get_task(task_id)
        rows.append(
            {
                "task_id": task.task_id,
                "class_name": task.__class__.__name__,
                "trigger_rule": str(task.trigger_rule),
                "upstream": ";".join(sorted(task.upstream_task_ids)),
                "downstream": ";".join(sorted(task.downstream_task_ids)),
                "ignore_downstream_trigger_rules": str(
                    getattr(task, "ignore_downstream_trigger_rules", "")
                ).lower(),
            }
        )
    return rows


def evaluate_scenario(
    row: dict[str, str], channel_task_map: dict[str, str], task_order: list[str]
) -> tuple[dict[str, str], dict[str, str]]:
    channels = [] if row["channels"] == "none" else row["channels"].split(";")
    targets = [channel_task_map[channel] for channel in channels] or ["no_channel"]
    states = {"load_manifest": "SUCCESS", "choose_channels": "SUCCESS"}
    for channel, task_id in channel_task_map.items():
        states[task_id] = row[f"{channel}_state"] if channel in channels else "SKIPPED"
    states["no_channel"] = "SUCCESS" if not channels else "SKIPPED"
    branch_states = [states[task_id] for task_id in channel_task_map.values()] + [
        states["no_channel"]
    ]
    if any(state in {"FAILED", "UPSTREAM_FAILED"} for state in branch_states):
        join_state = "UPSTREAM_FAILED"
    elif any(state == "SUCCESS" for state in branch_states):
        join_state = "SUCCESS"
    else:
        join_state = "SKIPPED"
    states["selected_join"] = join_state
    states["risk_gate"] = "SUCCESS" if join_state == "SUCCESS" else join_state
    allows = bool(channels) and row["risk_decision"] == "ALLOW"
    if join_state == "SUCCESS":
        states["promote"] = "SUCCESS" if allows else "SKIPPED"
    elif join_state == "SKIPPED":
        states["promote"] = "SKIPPED"
    else:
        states["promote"] = "UPSTREAM_FAILED"
    states["finalize"] = "SUCCESS"
    if set(states) != set(task_order):
        raise ValueError(f"{row['scenario_id']}: state task set mismatch")
    decision = {
        "scenario_id": row["scenario_id"],
        "branch_targets": ";".join(targets),
        "short_circuit_allows": str(allows).lower(),
        "join_state": join_state,
        "promote_state": states["promote"],
        "finalize_state": states["finalize"],
    }
    return states, decision


def validate_scenarios(rows: list[dict[str, str]], contract: dict) -> None:
    if [row["scenario_id"] for row in rows] != contract["scenario_order"]:
        raise ValueError("scenario order mismatch")
    if len({row["scenario_id"] for row in rows}) != len(rows):
        raise ValueError("duplicate scenario_id")
    allowed_channels = set(contract["channel_task_map"])
    allowed_states = set(contract["allowed_selected_states"])
    allowed_risks = set(contract["allowed_risk_decisions"])
    for row in rows:
        channels = [] if row["channels"] == "none" else row["channels"].split(";")
        if len(channels) != len(set(channels)) or not set(channels) <= allowed_channels:
            raise ValueError(f"{row['scenario_id']}: invalid channels")
        if row["risk_decision"] not in allowed_risks:
            raise ValueError(f"{row['scenario_id']}: invalid risk_decision")
        for channel in allowed_channels:
            value = row[f"{channel}_state"]
            if channel in channels and value not in allowed_states:
                raise ValueError(f"{row['scenario_id']}: invalid selected state")
            if channel not in channels and value != "-":
                raise ValueError(f"{row['scenario_id']}: unselected state must be dash")


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit(
            "usage: audit_release_dag.py REFERENCE_ROOT INPUT_ROOT DAG_ROOT OUTPUT_ROOT"
        )
    reference_root, input_root, dag_root, output_root = map(Path, sys.argv[1:])
    if relative_files(input_root) != INPUT_FILES:
        raise SystemExit("input boundary mismatch")
    if relative_files(dag_root) != DAG_FILES:
        raise SystemExit("DAG boundary mismatch")
    if output_root.exists() and (not output_root.is_dir() or any(output_root.iterdir())):
        raise SystemExit("output directory must be absent or empty")

    contract = json.loads((input_root / "state_contract.json").read_text(encoding="utf-8"))
    if contract.get("contract_id") != "internet-release-skip-v2":
        raise SystemExit("contract version mismatch")
    if contract.get("required_input_files") != INPUT_FILES:
        raise SystemExit("contract input boundary mismatch")
    if contract.get("required_dag_files") != DAG_FILES:
        raise SystemExit("contract DAG boundary mismatch")
    if contract.get("required_result_files") != RESULT_FILES:
        raise SystemExit("contract result boundary mismatch")
    scenarios = load_csv(input_root / "release_scenarios.csv", SCENARIO_HEADERS)
    validate_scenarios(scenarios, contract)

    bag = DagBag(dag_folder=str(dag_root), include_examples=False, safe_mode=False)
    if bag.import_errors:
        raise SystemExit(f"DagBag import errors: {bag.import_errors}")
    dag = bag.dags.get(contract["dag_id"])
    if dag is None or set(dag.task_ids) != set(contract["task_order"]):
        raise SystemExit("DAG identity or task set mismatch")
    graph = graph_rows(dag, contract["task_order"])

    expected_branch_targets = set(contract["branch_targets"])
    branch = dag.get_task(contract["branch_task"])
    join = dag.get_task(contract["join_task"])
    risk = dag.get_task(contract["risk_task"])
    promote = dag.get_task(contract["promote_task"])
    final = dag.get_task(contract["final_task"])
    graph_checks = {
        "branch_operator": branch.__class__.__name__ == "BranchPythonOperator",
        "branch_targets": set(branch.downstream_task_ids) == expected_branch_targets,
        "join_upstreams": set(join.upstream_task_ids) == expected_branch_targets,
        "join_rule": str(join.trigger_rule) == contract["join_trigger_rule"],
        "risk_operator": risk.__class__.__name__ == "ShortCircuitOperator",
        "risk_preserves_downstream_rules": risk.ignore_downstream_trigger_rules is False,
        "promote_edge": promote.upstream_task_ids == {contract["risk_task"]},
        "final_edge": final.upstream_task_ids == {contract["promote_task"]},
        "final_rule": str(final.trigger_rule) == contract["final_trigger_rule"],
    }
    if not all(graph_checks.values()):
        raise SystemExit(f"DAG graph contract mismatch: {graph_checks}")

    states_rows = []
    decisions = []
    for scenario in scenarios:
        states, decision = evaluate_scenario(
            scenario, contract["channel_task_map"], contract["task_order"]
        )
        decisions.append(decision)
        states_rows.extend(
            {
                "scenario_id": scenario["scenario_id"],
                "task_id": task_id,
                "state": states[task_id],
            }
            for task_id in contract["task_order"]
        )

    truth_rows = []
    for case in contract["truth_cases"]:
        if case["success"] + case["failed"] + case["skipped"] != 4:
            raise SystemExit("truth case upstream count mismatch")
        if case["failed"] > 0:
            decision, terminal = "BLOCK", "UPSTREAM_FAILED"
        elif case["success"] > 0:
            decision, terminal = "RUN", "SUCCESS"
        else:
            decision, terminal = "BLOCK", "SKIPPED"
        truth_rows.append({**case, "decision": decision, "terminal_state": terminal})

    state_counts: dict[str, int] = {}
    for row in states_rows:
        state_counts[row["state"]] = state_counts.get(row["state"], 0) + 1
    controls = {
        "contract_id": contract["contract_id"],
        "dag_id": dag.dag_id,
        "tasks": len(dag.task_ids),
        "scenarios": len(scenarios),
        "state_rows": len(states_rows),
        "branch_decision_rows": len(decisions),
        "truth_cases": len(truth_rows),
        "state_counts": state_counts,
    }
    invariants = {
        "input_file_boundary": relative_files(input_root) == INPUT_FILES,
        "dag_file_boundary": relative_files(dag_root) == DAG_FILES,
        "contract_v2": contract["contract_id"] == "internet-release-skip-v2",
        "dag_imports_without_errors": not bag.import_errors,
        "exact_task_order": [row["task_id"] for row in graph] == contract["task_order"],
        "branch_is_branch_python_operator": graph_checks["branch_operator"],
        "branch_has_four_direct_targets": graph_checks["branch_targets"],
        "join_has_four_upstreams": graph_checks["join_upstreams"],
        "join_rule_is_none_failed_min_one_success": graph_checks["join_rule"],
        "risk_gate_is_short_circuit": graph_checks["risk_operator"],
        "risk_gate_preserves_downstream_rules": graph_checks[
            "risk_preserves_downstream_rules"
        ],
        "finalize_only_follows_promote": graph_checks["final_edge"],
        "final_rule_is_all_done": graph_checks["final_rule"],
        "ten_scenarios_accounted": len(decisions) == 10,
        "one_hundred_state_rows": len(states_rows) == 100,
        "all_finalizers_succeed": all(row["finalize_state"] == "SUCCESS" for row in decisions),
        "blocked_or_empty_runs_do_not_promote": all(
            row["promote_state"] != "SUCCESS"
            for row in decisions
            if row["scenario_id"] in {"S03", "S04", "S10"}
        ),
        "selected_failures_propagate_upstream_failed": all(
            row["join_state"] == "UPSTREAM_FAILED"
            for row in decisions
            if row["scenario_id"] in {"S05", "S06"}
        ),
        "selected_skip_only_yields_skipped_join": next(
            row for row in decisions if row["scenario_id"] == "S07"
        )["join_state"]
        == "SKIPPED",
        "truth_table_matches_join_rule": all(
            (row["decision"] == "RUN")
            == (row["success"] > 0 and row["failed"] == 0)
            for row in truth_rows
        ),
    }
    if len(invariants) != 20 or not all(invariants.values()):
        raise SystemExit(f"invariant failure: {invariants}")

    output_root.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=f".{output_root.name}.staging-", dir=output_root.parent)
    )
    published = False
    try:
        write_csv(stage / "task_graph.csv", list(graph[0]), graph)
        write_csv(stage / "branch_decisions.csv", list(decisions[0]), decisions)
        write_csv(
            stage / "scenario_states.csv",
            ["scenario_id", "task_id", "state"],
            states_rows,
        )
        write_csv(stage / "trigger_truth_table.csv", list(truth_rows[0]), truth_rows)
        (stage / "state_summary.json").write_text(
            json.dumps(controls, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        validation = {
            "engine": {
                "airflow_version": airflow.__version__,
                "dagbag_import": True,
                "scheduler_started": False,
                "metadata_database_accessed": False,
                "network_access": False,
            },
            "controls": controls,
            "invariants": invariants,
            "result": "PASS",
        }
        (stage / "validation.json").write_text(
            json.dumps(validation, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        if relative_files(stage) != RESULT_FILES:
            raise RuntimeError("staging result boundary mismatch")
        test_env = {
            **os.environ,
            "ALE_INPUT_ROOT": str(input_root),
            "ALE_DAG_ROOT": str(dag_root),
            "ALE_OUTPUT_ROOT": str(stage),
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        tested = subprocess.run(
            [sys.executable, str(reference_root / "tests/test_results.py")],
            env=test_env,
            text=True,
            capture_output=True,
            timeout=45,
            check=False,
        )
        if tested.returncode != 0:
            raise RuntimeError(tested.stderr or tested.stdout)
        if output_root.exists():
            output_root.rmdir()
        os.replace(stage, output_root)
        published = True
        print(tested.stdout.strip())
        print("5176 Airflow release convergence audit PASS")
    finally:
        if not published and stage.exists():
            shutil.rmtree(stage)


if __name__ == "__main__":
    main()
