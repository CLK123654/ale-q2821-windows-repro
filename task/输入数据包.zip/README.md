# Multichannel release convergence fixture

This fictional offline fixture models scheduler terminal states for an internet API, web and mobile release. It is not copied from a production DAG, deployment system, Airflow metadata database or incident record. No endpoint, credential, customer identifier or live release is included.

`release_scenarios.csv` contains ten release decisions. A dash means that the channel was not selected;`SKIPPED` on a selected channel is an explicit terminal result and must not be rewritten as a branch omission.`state_contract.json` is the only file, graph and state contract.`broken_dag.py` is an intentionally incomplete starter that omits the no-channel branch, risk gate, finalizer and required trigger rules.

All four files are read-only. The exercise imports only the submitted DAG and evaluates the published scenarios without starting an Airflow scheduler, worker, webserver or external deployment call.
