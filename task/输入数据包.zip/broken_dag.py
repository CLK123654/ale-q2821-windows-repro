from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator

with DAG("internet_multichannel_release", schedule=None) as dag:
    choose_channels = BranchPythonOperator(task_id="choose_channels", python_callable=lambda: "deploy_web")
    deploy_api = EmptyOperator(task_id="deploy_api")
    deploy_web = EmptyOperator(task_id="deploy_web")
    deploy_mobile = EmptyOperator(task_id="deploy_mobile")
    selected_join = EmptyOperator(task_id="selected_join")  # wrong default all_success
    choose_channels >> [deploy_api, deploy_web, deploy_mobile] >> selected_join
